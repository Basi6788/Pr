/**
 * ============================================================================
 * FF-OMNI-PROXY v3.1: Lobby Anti-Ban Fix + Full .TXT Log Exporter +
 * Default Guest Bundle & Clothes Manifest Parser
 * ============================================================================
 */

const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');

const KEYS = require('./config/keys');
const {
  sessionState,
  aesCbcEncrypt,
  aesCbcDecryptSmart,
  parseUdpDatagram,
  parseTcpFrame
} = require('./crypto/cipherEngine');
const { SCHEMAS, decodeProtobuf, encodeProtobuf } = require('./proto/protoEngine');
const { MESSAGE_ID_TO_NAME } = require('./proto/messageIds');
const {
  inspectHttpBody,
  classifyUrlPurpose,
  ensureDedicatedPortForOrigin,
  getAllocatedPortsList,
  getMediaFromCache,
  responseModConfig
} = require('./proxy/httpInterceptor');
const { createUnifiedPort8080Server } = require('./proxy/tcpInterceptor');
const { createUdpInterceptor } = require('./proxy/udpInterceptor');

const DASHBOARD_PORT = Number(process.env.PORT || 3000);
const UNIFIED_PROXY_PORT = Number(process.env.PROXY_PORT || 8080);

const packetHistory = [];
const MAX_HISTORY = 1000;
const TXT_LOG_FILE = path.join(__dirname, 'ff_all_requests_log.txt');

const C = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  cyan: '\x1b[36m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  magenta: '\x1b[35m',
  red: '\x1b[31m',
  blue: '\x1b[34m',
  white: '\x1b[37m'
};

/**
 * Format a single packet as plain text for .TXT download & live file logging
 */
function formatPacketForTxtFile(pkt, indexNum = 1) {
  const status = pkt.statusCode || 200;
  const portNum = pkt.capturedPort || 8080;
  const purposeBadge = pkt.urlMeta?.badge || pkt.protocol;
  const purposeDesc = pkt.urlMeta?.purpose || pkt.packetType || pkt.cmdName || '';

  const lines = [
    `================================================================================`,
    `PACKET #${indexNum} | [${pkt.protocol} :${portNum}] | STATUS: ${status} | TIME: ${pkt.timestamp}`,
    `PURPOSE / ROLE : ${purposeBadge} — ${purposeDesc}`,
    `FULL URL / OP  : ${pkt.fullUrl || pkt.requestTitle || pkt.cmdName}`,
    `WIRE MODE      : ${pkt.passthroughMode || 'EXACT_ENCRYPTED_WIRE_PASSTHROUGH'}`,
    `REQ CIPHER     : ${pkt.request?.encryption || 'NONE'} (${pkt.request?.size || 0} B)`,
    `RES CIPHER     : ${pkt.response?.encryption || pkt.encryptionStatus || 'RAW'} (${pkt.response?.size || pkt.size || 0} B)`
  ];

  if (pkt.discoveredPortMappings && Object.keys(pkt.discoveredPortMappings).length > 0) {
    lines.push(`--- PORT ROUTING & PROTECTED ANTI-BAN URLS ---`);
    for (const [k, info] of Object.entries(pkt.discoveredPortMappings)) {
      lines.push(`  • ${k}: ${info.originalUrl} ==> ${info.rewrittenUrl} [${info.status}]`);
    }
  }

  if (pkt.request?.headers && Object.keys(pkt.request.headers).length > 0) {
    lines.push(`--- OUTGOING REQUEST HEADERS ---`);
    lines.push(JSON.stringify(pkt.request.headers, null, 2));
  }

  if (pkt.request?.decoded) {
    lines.push(`--- OUTGOING REQUEST DECODED PAYLOAD ---`);
    lines.push(JSON.stringify(pkt.request.decoded, null, 2));
  }

  if (pkt.request?.rawHex) {
    lines.push(`--- OUTGOING REQUEST ENCRYPTED/RAW HEX ---`);
    lines.push(pkt.request.rawHex);
  }

  if (pkt.response?.headers && Object.keys(pkt.response.headers).length > 0) {
    lines.push(`--- INCOMING RESPONSE HEADERS (Status ${status}) ---`);
    lines.push(JSON.stringify(pkt.response.headers, null, 2));
  }

  if (pkt.response?.decoded || pkt.decodedPayload) {
    lines.push(`--- INCOMING RESPONSE DECODED PAYLOAD (Status ${status}) ---`);
    lines.push(JSON.stringify(pkt.response?.decoded || pkt.decodedPayload, null, 2));
  }

  if (pkt.response?.rawHex || pkt.rawHex) {
    lines.push(`--- INCOMING RESPONSE ENCRYPTED/RAW HEX ---`);
    lines.push(pkt.response?.rawHex || pkt.rawHex);
  }

  lines.push(`================================================================================\n`);
  return lines.join('\n');
}

/**
 * Generate full .TXT report for all captured requests (or filtered by clothes/skins)
 */
function buildFullTxtExport(filterMode = 'ALL') {
  const list = filterMode === 'CLOTHES'
    ? packetHistory.filter((p) => p.urlMeta?.isClothesOrSkin)
    : packetHistory;

  const header = [
    `################################################################################`,
    `# FF-OMNI-PROXY v3.1 — COMPLETE CAPTURED TRAFFIC REPORT (.TXT)                 #`,
    `# Generated At : ${new Date().toISOString()}                                   #`,
    `# Total Packets: ${list.length} (Filter: ${filterMode})                        #`,
    `# Dedicated Prts: ${getAllocatedPortsList().map((p) => ':' + p.port + '=' + p.host).join(', ')}`,
    `################################################################################\n`
  ].join('\n');

  const body = list.map((pkt, idx) => formatPacketForTxtFile(pkt, idx + 1)).join('\n');
  return header + body;
}

function logPacketToTerminal(pkt) {
  const status = pkt.statusCode || 200;
  const statusColor = status >= 200 && status < 300 ? C.green : status >= 400 ? C.red : C.yellow;
  const protoColor = pkt.protocol === 'HTTP' ? C.cyan : pkt.protocol === 'TCP' ? C.magenta : C.green;
  const portNum = pkt.capturedPort || 8080;
  const timeStr = (pkt.timestamp || new Date().toISOString()).split('T')[1]?.replace('Z', '') || '';

  const line = `${protoColor}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${C.reset}`;
  console.log(`\n${line}`);

  if (pkt.protocol === 'HTTP') {
    const reqTitle = pkt.requestTitle || `[Port :${portNum}] ${pkt.method} ${pkt.fullUrl}`;
    const resTitle = pkt.responseTitle || `${status} <- ${pkt.host}${pkt.path}`;
    const purposeBadge = pkt.urlMeta?.badge || '🌐 GAME URL';
    const purposeDesc = pkt.urlMeta?.purpose || '';

    console.log(
      `${C.bold}${protoColor}[HTTP :${portNum}]${C.reset} ${C.bold}${C.magenta}${purposeBadge}${C.reset} ${C.dim}(${purposeDesc})${C.reset}`
    );
    console.log(
      `${C.bold}${protoColor}[HTTP :${portNum}]${C.reset} ${C.bold}${C.yellow}REQUEST TITLE :${C.reset} ${C.white}${reqTitle}${C.reset}`
    );
    console.log(
      `${C.bold}${protoColor}[HTTP :${portNum}]${C.reset} ${C.bold}${statusColor}RESPONSE TITLE:${C.reset} ${statusColor}Status ${status}${C.reset} (${pkt.durationMs || 0}ms) | ${resTitle}`
    );
    console.log(
      `${C.dim}[TIME: ${timeStr}] [MODE: ${pkt.passthroughMode || 'EXACT_PASSTHROUGH'}] [REQ: ${pkt.request?.encryption || 'NONE'}] [RES: ${pkt.response?.encryption || 'NONE'}]${C.reset}`
    );

    if (pkt.discoveredPortMappings && Object.keys(pkt.discoveredPortMappings).length > 0) {
      console.log(`${C.magenta}  ★ [ANTI-BAN PROTECTED & DEDICATED PORT URL ROUTING]:${C.reset}`);
      for (const [k, info] of Object.entries(pkt.discoveredPortMappings)) {
        const stCol = info.status.includes('PROTECTED') ? C.green : C.yellow;
        console.log(`    • ${k}: ${stCol}[${info.status}]${C.reset} ==> ${info.rewrittenUrl}`);
      }
    }

    if (pkt.request?.decoded) {
      console.log(`${C.cyan}  ▸ [OUTGOING REQUEST DECODED]:${C.reset}`);
      console.log(formatJsonForTerminal(pkt.request.decoded));
    }
    if (pkt.response?.decoded) {
      console.log(`${C.green}  ◂ [INCOMING RESPONSE DECODED (Status ${status})]:${C.reset}`);
      console.log(formatJsonForTerminal(pkt.response.decoded));
    }
  } else if (pkt.protocol === 'TCP') {
    const reqTitle = pkt.requestTitle || `[TCP :${portNum}] ${pkt.packetType} (${pkt.source} -> ${pkt.destination})`;
    const resTitle = pkt.responseTitle || `Status ${status} | ${pkt.packetType}`;
    console.log(
      `${C.bold}${protoColor}[TCP :${portNum}]${C.reset} ${C.bold}${C.yellow}REQUEST TITLE :${C.reset} ${C.white}${reqTitle}${C.reset}`
    );
    console.log(
      `${C.bold}${protoColor}[TCP :${portNum}]${C.reset} ${C.bold}${statusColor}RESPONSE TITLE:${C.reset} ${statusColor}Status ${status}${C.reset} | ${resTitle}`
    );
    if (pkt.decodedPayload) {
      console.log(`${C.magenta}  ▸ [DECRYPTED TCP PAYLOAD]:${C.reset}`);
      console.log(formatJsonForTerminal(pkt.decodedPayload));
    }
  } else if (pkt.protocol === 'UDP') {
    const reqTitle = pkt.requestTitle || `[UDP :${portNum}] ${pkt.cmdName} (cmd=${pkt.cmdId})`;
    const resTitle = pkt.responseTitle || `Status ${status} | ${pkt.cmdName}`;
    console.log(
      `${C.bold}${protoColor}[UDP :${portNum}]${C.reset} ${C.bold}${C.yellow}REQUEST TITLE :${C.reset} ${C.white}${reqTitle}${C.reset}`
    );
    console.log(
      `${C.bold}${protoColor}[UDP :${portNum}]${C.reset} ${C.bold}${statusColor}RESPONSE TITLE:${C.reset} ${statusColor}Status ${status}${C.reset} | ${resTitle}`
    );
    if (pkt.decodedPayload) {
      console.log(`${C.green}  ▸ [DECRYPTED UDP PAYLOAD]:${C.reset}`);
      console.log(formatJsonForTerminal(pkt.decodedPayload));
    }
  }
}

function formatJsonForTerminal(obj) {
  try {
    const str = JSON.stringify(obj, null, 2);
    const lines = str.split('\n');
    const maxLines = 80;
    const clipped = lines.slice(0, maxLines).map((l) => `    ${l}`);
    if (lines.length > maxLines) {
      clipped.push(`    ... (${lines.length - maxLines} more lines — download .TXT on Dashboard :3000)`);
    }
    return clipped.join('\n');
  } catch (_) {
    return `    ${String(obj)}`;
  }
}

const BUILTIN_SOCKET_IO_CLIENT_JS = `
(function(window) {
  function io(url) {
    const listeners = {};
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = (url ? url.replace(/^http/, 'ws') : (proto + '//' + location.host)) + '/socket.io/?EIO=4&transport=websocket';
    let ws = null;
    let reconnectTimer = null;

    const socket = {
      connected: false,
      on(event, fn) {
        if (!listeners[event]) listeners[event] = [];
        listeners[event].push(fn);
        return socket;
      },
      emit(event, data) {
        if (ws && ws.readyState === 1) {
          ws.send(JSON.stringify({ event, data }));
        }
        return socket;
      }
    };

    function trigger(event, payload) {
      (listeners[event] || []).forEach(fn => {
        try { fn(payload); } catch (e) { console.error(e); }
      });
    }

    function connect() {
      ws = new WebSocket(wsUrl);
      ws.onopen = () => {
        socket.connected = true;
        trigger('connect');
      };
      ws.onmessage = (msg) => {
        try {
          const parsed = JSON.parse(msg.data);
          if (parsed && parsed.event) {
            trigger(parsed.event, parsed.data);
          }
        } catch (e) {}
      };
      ws.onclose = () => {
        socket.connected = false;
        trigger('disconnect');
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(connect, 2000);
      };
    }

    connect();
    return socket;
  }
  window.io = io;
})(window);
`;

function attachSocketIoServer(httpServer, onClientConnection) {
  try {
    const { Server } = require('socket.io');
    const io = new Server(httpServer, { cors: { origin: '*' } });
    io.on('connection', (socket) => onClientConnection(socket, io));
    return {
      mode: 'socket.io (npm)',
      emit: (event, data) => io.emit(event, data)
    };
  } catch (_) {
    const clients = new Set();

    const broadcast = (event, data) => {
      const payload = Buffer.from(JSON.stringify({ event, data }), 'utf8');
      const frame = encodeWsFrame(payload);
      for (const sock of clients) {
        if (!sock.destroyed) sock.write(frame);
      }
    };

    httpServer.on('upgrade', (req, socket) => {
      const key = req.headers['sec-websocket-key'];
      if (!key) {
        socket.destroy();
        return;
      }
      const accept = crypto
        .createHash('sha1')
        .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
        .digest('base64');

      socket.write(
        'HTTP/1.1 101 Switching Protocols\r\n' +
          'Upgrade: websocket\r\n' +
          'Connection: Upgrade\r\n' +
          `Sec-WebSocket-Accept: ${accept}\r\n\r\n`
      );

      clients.add(socket);
      const clientListeners = {};

      const clientWrapper = {
        emit: (event, data) => {
          if (!socket.destroyed) {
            const buf = Buffer.from(JSON.stringify({ event, data }), 'utf8');
            socket.write(encodeWsFrame(buf));
          }
        },
        on: (event, fn) => {
          if (!clientListeners[event]) clientListeners[event] = [];
          clientListeners[event].push(fn);
        }
      };

      onClientConnection(clientWrapper, { emit: broadcast });

      socket.on('data', (buf) => {
        const msgStr = decodeWsFrame(buf);
        if (!msgStr) return;
        try {
          const parsed = JSON.parse(msgStr);
          if (parsed && parsed.event && clientListeners[parsed.event]) {
            clientListeners[parsed.event].forEach((fn) => fn(parsed.data));
          }
        } catch (_) {}
      });

      socket.on('close', () => clients.delete(socket));
      socket.on('error', () => clients.delete(socket));
    });

    return {
      mode: 'socket.io (built-in RFC6455 engine)',
      emit: broadcast
    };
  }
}

function encodeWsFrame(dataBuf) {
  const len = dataBuf.length;
  let header;
  if (len < 126) {
    header = Buffer.from([0x81, len]);
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x81;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x81;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  return Buffer.concat([header, dataBuf]);
}

function decodeWsFrame(buf) {
  if (buf.length < 2) return null;
  const opcode = buf[0] & 0x0f;
  if (opcode === 0x08) return null;
  const masked = (buf[1] & 0x80) !== 0;
  let len = buf[1] & 0x7f;
  let offset = 2;
  if (len === 126) {
    if (buf.length < 4) return null;
    len = buf.readUInt16BE(2);
    offset = 4;
  } else if (len === 127) {
    if (buf.length < 10) return null;
    len = Number(buf.readBigUInt64BE(2));
    offset = 10;
  }
  let maskKey = null;
  if (masked) {
    if (buf.length < offset + 4) return null;
    maskKey = buf.subarray(offset, offset + 4);
    offset += 4;
  }
  if (buf.length < offset + len) return null;
  const payload = Buffer.from(buf.subarray(offset, offset + len));
  if (masked && maskKey) {
    for (let i = 0; i < payload.length; i++) {
      payload[i] ^= maskKey[i % 4];
    }
  }
  return payload.toString('utf8');
}

function getLocalLanIp() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const netInfo of nets[name] || []) {
      if (netInfo.family === 'IPv4' && !netInfo.internal) {
        return netInfo.address;
      }
    }
  }
  return '127.0.0.1';
}

function generateVerificationPackets() {
  const lanIp = getLocalLanIp();
  const events = [];

  // 1. /live/ver.php showing ALL Anti-Ban URLs Protected & Only Clothes/HotUpdate CDNs on :8083/:8085
  const verQuery = {
    version: '1.132.16',
    lang: 'en',
    device: 'android',
    channel: 'android',
    appstore: 'googleplay',
    region: 'PK',
    release_version: 'OB55',
    whitelist_version: '1.8.1',
    whitelist_sp_version: '1.0.0',
    device_name: 'samsung SM-N986U1'
  };
  const verUrl = 'https://version.ggwhitehawk.com/live/ver.php?' + new URLSearchParams(verQuery).toString();
  const verResObj = {
    code: 0,
    is_server_open: true,
    is_firewall_open: false,
    cdn_url: `http://${lanIp}:8083/live/ABHotUpdates/`,
    backup_cdn_url: `http://${lanIp}:8083/live/ABHotUpdates/`,
    abhotupdate_cdn_url: `http://${lanIp}:8085/live/ABHotUpdates/`,
    img_cdn_url: 'https://dl.gmc.freefiremobile.com/common/',
    server_url: 'https://loginbp.ppmainecoonghj.com/',
    network_log_server: 'https://sgnetwork.ggblueshark.com/',
    web_log_server: 'https://networkselftest.ff.garena.com/api/',
    billboard_cdn_url: 'https://cdn.wildflamestudio.com/common/OB55/CSH/patchupdate/pkennbgiuabA101.ff_extend;https://cdn.wildflamestudio.com/common/OB55/CSH/patchupdate/pkennbgiuabA102.ff_extend',
    latest_release_version: 'OB55',
    remote_version: '1.132.16',
    vercfg_sign: '1.16032533697c9e9e'
  };
  const verResBody = Buffer.from(JSON.stringify(verResObj), 'utf8');
  events.push({
    id: `HTTP-${Date.now()}-ver0`,
    protocol: 'HTTP',
    capturedPort: 8080,
    direction: 'CLIENT <-> SERVER',
    timestamp: new Date().toISOString(),
    durationMs: 39,
    method: 'GET',
    fullUrl: verUrl,
    host: 'version.ggwhitehawk.com',
    path: '/live/ver.php',
    queryParams: verQuery,
    statusCode: 200,
    urlMeta: classifyUrlPurpose(verUrl, '/live/ver.php', 'application/json'),
    passthroughMode: 'RESPONSE_MODIFIED (cdn_url -> :8083, abhotupdate_cdn_url -> :8085 | All Anti-Ban Log/CSH URLs Protected)',
    discoveredPortMappings: {
      cdn_url: {
        originalUrl: 'https://dl.gmc.freefiremobile.com/live/ABHotUpdates/',
        rewrittenUrl: `http://${lanIp}:8083/live/ABHotUpdates/`,
        port: 8083,
        status: 'REDIRECTED_TO_PORT_8083'
      },
      abhotupdate_cdn_url: {
        originalUrl: 'https://core-gmc.freefiremobile.com/live/ABHotUpdates/',
        rewrittenUrl: `http://${lanIp}:8085/live/ABHotUpdates/`,
        port: 8085,
        status: 'REDIRECTED_TO_PORT_8085'
      },
      server_url: {
        originalUrl: 'https://loginbp.ppmainecoonghj.com/',
        rewrittenUrl: 'https://loginbp.ppmainecoonghj.com/',
        port: 'DIRECT',
        status: 'PROTECTED_UNTOUCHED'
      },
      network_log_server: {
        originalUrl: 'https://sgnetwork.ggblueshark.com/',
        rewrittenUrl: 'https://sgnetwork.ggblueshark.com/',
        port: 'DIRECT',
        status: 'PROTECTED_UNTOUCHED'
      },
      web_log_server: {
        originalUrl: 'https://networkselftest.ff.garena.com/api/',
        rewrittenUrl: 'https://networkselftest.ff.garena.com/api/',
        port: 'DIRECT',
        status: 'PROTECTED_UNTOUCHED'
      },
      billboard_cdn_url: {
        originalUrl: 'https://cdn.wildflamestudio.com/common/OB55/CSH/patchupdate/pkennbgiuabA101.ff_extend;...',
        rewrittenUrl: 'https://cdn.wildflamestudio.com/common/OB55/CSH/patchupdate/pkennbgiuabA101.ff_extend;...',
        port: 'DIRECT',
        status: 'PROTECTED_UNTOUCHED'
      }
    },
    requestTitle: `[Port :8080] GET ${verUrl}`,
    responseTitle: `200 OK <- version.ggwhitehawk.com/live/ver.php`,
    request: {
      headers: {
        Host: 'version.ggwhitehawk.com',
        'User-Agent': KEYS.GARENA_OAUTH.UNITY_USER_AGENT_2018,
        'X-Unity-Version': '2018.4.12f1'
      },
      ...inspectHttpBody(Buffer.alloc(0), {}, '/live/ver.php', 'REQUEST', verQuery)
    },
    response: {
      headers: { 'Content-Type': 'application/json; charset=utf-8' },
      ...inspectHttpBody(verResBody, { 'content-type': 'application/json' }, '/live/ver.php', 'RESPONSE')
    }
  });

  // 2. Default Guest Avatar & Clothes Bundle Manifest (optionalavatarres/794/fileinfo on :8083)
  const fileInfoText =
    'optionalab_avatar_01,7qxOw9WAx0SE5TicAye2qDIVaBM=,1242818,0,h382/Vl8AGYUrciC6AEKpmclhsE=,1114381,True,15.' +
    'optionalab_avatar_03,9KvLbSTph6nIF0+mWlN/YIxiCWA=,815666,0,ykyp+XoFBMFliV4B74JD5rADI4s=,741704,True,15.' +
    'optionalab_avatar_04,OcP5mKh4kodOHM2cxfeyx3cnfWY=,1438037,0,DogESg07WATtIMsWGymGjy/ncSA=,1310920,True,15';
  const fileInfoBuf = Buffer.from(fileInfoText, 'utf8');
  const fileInfoUrl = 'https://dl.gmc.freefiremobile.com/live/ABHotUpdates/android_astc/optional/optionalavatarres/794/fileinfo';
  const fileInfoPath = '/live/ABHotUpdates/android_astc/optional/optionalavatarres/794/fileinfo';
  const fileInfoRes = inspectHttpBody(fileInfoBuf, { 'content-type': 'application/octet-stream' }, fileInfoPath, 'RESPONSE');
  delete fileInfoRes.decompressedBuffer;
  events.push({
    id: `HTTP-${Date.now()}-finfo1`,
    protocol: 'HTTP',
    capturedPort: 8083,
    direction: 'CLIENT <-> SERVER',
    timestamp: new Date().toISOString(),
    durationMs: 45,
    method: 'GET',
    fullUrl: fileInfoUrl,
    host: 'dl.gmc.freefiremobile.com',
    path: fileInfoPath,
    queryParams: {},
    statusCode: 200,
    urlMeta: classifyUrlPurpose(fileInfoUrl, fileInfoPath, 'application/octet-stream'),
    passthroughMode: 'EXACT_ENCRYPTED_WIRE_PASSTHROUGH',
    requestTitle: `[Port :8083] GET ${fileInfoUrl}`,
    responseTitle: `200 OK <- dl.gmc.freefiremobile.com${fileInfoPath}`,
    request: {
      headers: { Host: 'dl.gmc.freefiremobile.com', 'User-Agent': KEYS.GARENA_OAUTH.UNITY_USER_AGENT_2018 },
      size: 0,
      encryption: 'NONE (Empty Body)',
      rawHex: '',
      decryptedHex: '',
      decoded: null
    },
    response: {
      headers: { 'Content-Type': 'application/octet-stream', 'Content-Length': String(fileInfoBuf.length) },
      ...fileInfoRes
    }
  });

  // 3. Default Guest Bundle Icon (901000284_rgb.astc on Port 8083)
  const astcHeader = Buffer.from([
    0x13, 0xab, 0xa1, 0x5c,
    0x08, 0x08, 0x01,
    0x70, 0x00, 0x00,
    0x70, 0x00, 0x00,
    0x01, 0x00, 0x00
  ]);
  const blocksCount = 14 * 14;
  const astcBlocks = Buffer.alloc(blocksCount * 16);
  for (let i = 0; i < blocksCount; i++) {
    const offset = i * 16;
    const bx = i % 14;
    const by = Math.floor(i / 14);
    const r = Math.min(255, Math.floor((bx / 14) * 230) + 25);
    const g = Math.min(255, Math.floor((by / 14) * 190) + 40);
    const b = 240;
    astcBlocks[offset + 0] = 0xfc;
    astcBlocks[offset + 1] = 0xfd;
    astcBlocks[offset + 2] = 0xff;
    astcBlocks[offset + 3] = 0xff;
    astcBlocks[offset + 4] = 0xff;
    astcBlocks[offset + 5] = 0xff;
    astcBlocks[offset + 6] = 0xff;
    astcBlocks[offset + 7] = 0xff;
    astcBlocks.writeUInt16LE((r << 8) | r, offset + 8);
    astcBlocks.writeUInt16LE((g << 8) | g, offset + 10);
    astcBlocks.writeUInt16LE((b << 8) | b, offset + 12);
    astcBlocks.writeUInt16LE(0xffff, offset + 14);
  }
  const sampleAstcBuf = Buffer.concat([astcHeader, astcBlocks]);
  const astcUrl = 'https://dl.gmc.freefiremobile.com/live/ABHotUpdates/IconCDN/android/901000284_rgb.astc';
  const astcPath = '/live/ABHotUpdates/IconCDN/android/901000284_rgb.astc';
  const astcResInspect = inspectHttpBody(sampleAstcBuf, { 'content-type': 'application/octet-stream' }, astcPath, 'RESPONSE');
  delete astcResInspect.decompressedBuffer;

  events.push({
    id: `HTTP-${Date.now()}-astc2`,
    protocol: 'HTTP',
    capturedPort: 8083,
    direction: 'CLIENT <-> SERVER',
    timestamp: new Date().toISOString(),
    durationMs: 28,
    method: 'GET',
    fullUrl: astcUrl,
    host: 'dl.gmc.freefiremobile.com',
    path: astcPath,
    queryParams: {},
    statusCode: 200,
    urlMeta: classifyUrlPurpose(astcUrl, astcPath, 'application/octet-stream'),
    hasMediaPreview: true,
    mediaFormat: 'ASTC_GPU_TEXTURE',
    astcMeta: { blockX: 8, blockY: 8, blockZ: 1, width: 112, height: 112, depth: 1, fileName: '901000284_rgb.astc' },
    passthroughMode: 'EXACT_ENCRYPTED_WIRE_PASSTHROUGH',
    requestTitle: `[Port :8083] GET ${astcUrl}`,
    responseTitle: `200 OK <- dl.gmc.freefiremobile.com${astcPath}`,
    request: {
      headers: { Host: 'dl.gmc.freefiremobile.com', 'User-Agent': KEYS.GARENA_OAUTH.UNITY_USER_AGENT_2018 },
      size: 0,
      encryption: 'NONE (Empty Body)',
      rawHex: '',
      decryptedHex: '',
      decoded: null
    },
    response: {
      headers: { 'Content-Type': 'application/octet-stream', 'Content-Length': String(sampleAstcBuf.length) },
      ...astcResInspect
    },
    _seedMediaBuffer: sampleAstcBuf
  });

  return events;
}

async function startAllServers() {
  const publicDir = path.join(__dirname, 'public');
  const indexHtmlPath = path.join(publicDir, 'index.html');

  let ioHub = null;
  const seededMedia = new Map();

  function recordAndBroadcastPacket(packetEvent, printToTerminal = true) {
    if (packetEvent._seedMediaBuffer) {
      seededMedia.set(packetEvent.id, { buffer: packetEvent._seedMediaBuffer, contentType: 'application/octet-stream' });
      delete packetEvent._seedMediaBuffer;
    }
    packetHistory.unshift(packetEvent);
    if (packetHistory.length > MAX_HISTORY) packetHistory.pop();

    // Append live to ff_all_requests_log.txt in Termux directory
    try {
      fs.appendFileSync(TXT_LOG_FILE, formatPacketForTxtFile(packetEvent, packetHistory.length), 'utf8');
    } catch (_) {}

    if (printToTerminal) {
      logPacketToTerminal(packetEvent);
    }
    if (ioHub) {
      ioHub.emit('packet:new', packetEvent);
      ioHub.emit('ports:update', getAllocatedPortsList());
    }
  }

  // Pre-allocate Dedicated Ports for Clothes/Skins & HotUpdates ONLY
  ensureDedicatedPortForOrigin(
    'https://dl.bs.freefiremobile.com',
    'HotUpdate & Banner CDN (dl.bs.freefiremobile.com)',
    (pkt) => recordAndBroadcastPacket(pkt, true)
  );
  ensureDedicatedPortForOrigin(
    'https://core-bs.freefiremobile.com',
    'Core HotUpdate CDN (core-bs.freefiremobile.com)',
    (pkt) => recordAndBroadcastPacket(pkt, true)
  );
  ensureDedicatedPortForOrigin(
    'https://dl.gmc.freefiremobile.com',
    'Main Clothes, Default Bundles & ASTC Icon CDN (dl.gmc.freefiremobile.com)',
    (pkt) => recordAndBroadcastPacket(pkt, true)
  );
  ensureDedicatedPortForOrigin(
    'https://clientbp.ppmainecoonghj.com',
    'Post-Login Lobby & Outfit API (clientbp.ppmainecoonghj.com)',
    (pkt) => recordAndBroadcastPacket(pkt, true)
  );
  ensureDedicatedPortForOrigin(
    'https://core-gmc.freefiremobile.com',
    'Core GMC HotUpdate Manifest CDN (core-gmc.freefiremobile.com)',
    (pkt) => recordAndBroadcastPacket(pkt, true)
  );

  function serializeSessionState() {
    return {
      accountId: sessionState.accountId,
      nickname: sessionState.nickname,
      region: sessionState.region,
      serverUrl: sessionState.serverUrl,
      loginServerUrl: sessionState.loginServerUrl,
      staticAesKeyHex: KEYS.AES_CBC.KEY_HEX,
      staticAesKeyStr: KEYS.AES_CBC.KEY_STR,
      staticAesIvHex: KEYS.AES_CBC.IV_HEX,
      staticAesIvStr: KEYS.AES_CBC.IV_STR,
      dynamicAesKeyHex: sessionState.aesKey ? sessionState.aesKey.toString('hex') : null,
      dynamicAesIvHex: sessionState.aesIv ? sessionState.aesIv.toString('hex') : null,
      udpKeyHex: sessionState.udpKey ? sessionState.udpKey.toString('hex') : null,
      matchCode: sessionState.matchCode,
      allocatedPorts: getAllocatedPortsList(),
      responseModConfig
    };
  }

  const dashboardServer = http.createServer((req, res) => {
    const parsedReqUrl = new URL(req.url, `http://localhost:${DASHBOARD_PORT}`);
    const reqUrl = parsedReqUrl.pathname;

    if (reqUrl === '/socket.io/socket.io.js') {
      res.writeHead(200, { 'Content-Type': 'application/javascript; charset=utf-8' });
      res.end(BUILTIN_SOCKET_IO_CLIENT_JS);
      return;
    }

    // Download Complete Captured Traffic as .TXT file!
    if (reqUrl === '/api/export.txt') {
      const filterMode = (parsedReqUrl.searchParams.get('filter') || 'ALL').toUpperCase();
      const txtContent = buildFullTxtExport(filterMode);
      const fileName = filterMode === 'CLOTHES'
        ? `ff_clothes_skins_log_${Date.now()}.txt`
        : `ff_all_requests_log_${Date.now()}.txt`;
      res.writeHead(200, {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Disposition': `attachment; filename="${fileName}"`,
        'Content-Length': String(Buffer.byteLength(txtContent, 'utf8'))
      });
      res.end(txtContent);
      return;
    }

    if (reqUrl.startsWith('/api/media/')) {
      const pktId = decodeURIComponent(reqUrl.slice('/api/media/'.length));
      const item = getMediaFromCache(pktId) || seededMedia.get(pktId);
      if (!item) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Media not found in cache' }));
        return;
      }
      res.writeHead(200, {
        'Content-Type': item.contentType || 'application/octet-stream',
        'Content-Length': String(item.buffer.length),
        'Access-Control-Allow-Origin': '*'
      });
      res.end(item.buffer);
      return;
    }

    if (reqUrl === '/api/state' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          session: serializeSessionState(),
          ports: getAllocatedPortsList(),
          modifier: responseModConfig,
          packets: packetHistory.slice(0, 150)
        })
      );
      return;
    }

    if (reqUrl === '/' || reqUrl === '/index.html') {
      const html = fs.readFileSync(indexHtmlPath, 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(html);
      return;
    }

    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  });

  ioHub = attachSocketIoServer(dashboardServer, (socket) => {
    socket.emit('init:bundle', {
      session: serializeSessionState(),
      ports: getAllocatedPortsList(),
      modifier: responseModConfig,
      packets: packetHistory.slice(0, 150),
      schemas: Object.keys(SCHEMAS)
    });

    socket.on('simulate:suite', () => {
      const samplePackets = generateVerificationPackets();
      for (const pkt of samplePackets) {
        recordAndBroadcastPacket(pkt, true);
      }
    });

    socket.on('packets:clear', () => {
      packetHistory.length = 0;
      try {
        fs.writeFileSync(TXT_LOG_FILE, '', 'utf8');
      } catch (_) {}
      ioHub.emit('packets:cleared', {});
    });

    socket.on('modifier:update', (newCfg) => {
      if (newCfg && typeof newCfg === 'object') {
        if (typeof newCfg.bypassLoginServerUrl === 'boolean') {
          responseModConfig.bypassLoginServerUrl = newCfg.bypassLoginServerUrl;
        }
        if (typeof newCfg.redirectCdnUrlsToPorts === 'boolean') {
          responseModConfig.redirectCdnUrlsToPorts = newCfg.redirectCdnUrlsToPorts;
        }
        if (newCfg.verJsonOverrides && typeof newCfg.verJsonOverrides === 'object') {
          responseModConfig.verJsonOverrides = newCfg.verJsonOverrides;
        }
        if (Array.isArray(newCfg.customRules)) {
          responseModConfig.customRules = newCfg.customRules;
        }
      }
      ioHub.emit('modifier:state', responseModConfig);
    });

    socket.on('decrypt:manual', (reqData) => {
      const resData = handleManualDecrypt(reqData || {});
      socket.emit('decrypt:result', resData);
    });
  });

  const unifiedTcp8080 = createUnifiedPort8080Server({
    listenPort: UNIFIED_PROXY_PORT,
    onPacket: (pkt) => recordAndBroadcastPacket(pkt, true)
  });

  const unifiedUdp8080 = createUdpInterceptor({
    listenPort: UNIFIED_PROXY_PORT,
    onPacket: (pkt) => recordAndBroadcastPacket(pkt, true)
  });

  await Promise.all([
    new Promise((resolve) => dashboardServer.listen(DASHBOARD_PORT, '0.0.0.0', resolve)),
    unifiedTcp8080.start(),
    unifiedUdp8080.start()
  ]);

  // Initialize fresh txt log file
  try {
    fs.writeFileSync(TXT_LOG_FILE, `# FF-OMNI-PROXY v3.1 Live Traffic Capture Log (${new Date().toISOString()})\n\n`, 'utf8');
  } catch (_) {}

  const samples = generateVerificationPackets();
  for (const pkt of samples) {
    recordAndBroadcastPacket(pkt, false);
  }

  const lanIp = getLocalLanIp();
  console.log(`${C.bold}${C.cyan}╔════════════════════════════════════════════════════════════════════╗${C.reset}`);
  console.log(`${C.bold}${C.cyan}║  FF-OMNI-PROXY v3.1 (LOBBY ANTI-BAN FIX + .TXT EXPORT + SKINS)    ║${C.reset}`);
  console.log(`${C.bold}${C.cyan}╠════════════════════════════════════════════════════════════════════╣${C.reset}`);
  console.log(`${C.bold}║ [DASHBOARD UI]   http://localhost:${DASHBOARD_PORT}  (or http://${lanIp}:${DASHBOARD_PORT})${C.reset}`);
  console.log(`${C.bold}║ [Download .TXT]  http://localhost:${DASHBOARD_PORT}/api/export.txt               ║${C.reset}`);
  console.log(`${C.bold}║ [ANTI-BAN FIX]   network_log_server, web_log_server & CSH PROTECTED║${C.reset}`);
  console.log(`${C.bold}║ [CLOTHES PORTS]  :8083 (dl.gmc Skins/Bundles) | :8085 (core-gmc)   ║${C.reset}`);
  console.log(`${C.bold}${C.cyan}╚════════════════════════════════════════════════════════════════════╝${C.reset}`);

  return { dashboardServer, unifiedTcp8080, unifiedUdp8080 };
}

function handleManualDecrypt({ hexInput = '', mode = 'AUTO', schemaName = '', udpKeyHex = '', matchCode = '' }) {
  const cleanHex = String(hexInput).replace(/[^0-9a-fA-F]/g, '');
  if (!cleanHex || cleanHex.length % 2 !== 0) {
    return { ok: false, error: 'Please provide a valid even-length Hex string.' };
  }
  const buf = Buffer.from(cleanHex, 'hex');

  if (mode === 'UDP_TEA') {
    const customKey = udpKeyHex && udpKeyHex.length === 32 ? Buffer.from(udpKeyHex, 'hex') : null;
    return { ok: true, mode: 'UDP_TEA', result: parseUdpDatagram(buf, customKey, matchCode || null) };
  }
  if (mode === 'TCP_FRAME') {
    return { ok: true, mode: 'TCP_FRAME', result: parseTcpFrame(buf, 'MANUAL_INSPECT') };
  }
  if (mode === 'AES_CBC' || (mode === 'AUTO' && buf.length >= 16 && buf.length % 16 === 0)) {
    const aesRes = aesCbcDecryptSmart(buf);
    if (aesRes.success) {
      const pb = decodeProtobuf(aesRes.decryptedBuffer, schemaName || null);
      return {
        ok: true,
        mode: 'AES_128_CBC + PROTOBUF',
        encryption: aesRes.keyUsed,
        decryptedHex: aesRes.decryptedHex,
        schema: pb ? pb.schema : (schemaName || 'AutoWireProtobuf'),
        decoded: pb ? pb.fields : { utf8: aesRes.decryptedBuffer.toString('utf8') }
      };
    }
  }
  const pb = decodeProtobuf(buf, schemaName || null);
  return {
    ok: true,
    mode: 'DIRECT_PROTOBUF',
    decryptedHex: cleanHex,
    schema: pb ? pb.schema : (schemaName || 'AutoWireProtobuf'),
    decoded: pb ? pb.fields : { raw_utf8: buf.toString('utf8') }
  };
}

if (require.main === module) {
  if (process.argv.includes('--self-test')) {
    const samples = generateVerificationPackets();
    for (const s of samples) {
      logPacketToTerminal(s);
    }
    console.log(`\n[SELF-TEST OK] v3.1 Lobby Anti-Ban Fix, .TXT Log Exporter & Bundle Manifest Parser verified.`);
    process.exit(0);
  } else {
    startAllServers();
  }
}

module.exports = { startAllServers, generateVerificationPackets, handleManualDecrypt, logPacketToTerminal };
