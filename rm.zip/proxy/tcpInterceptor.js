/**
 * ============================================================================
 * FF-OMNI-PROXY v2.2: Stealth Port 8080 Multiplexer (HTTP + CONNECT + Raw TCP)
 * ============================================================================
 * Zero Proxy Fingerprint & 100% Untouched Encrypted Wire Passthrough:
 *  - Passes exact encrypted bytes between Client and Server without modification.
 *  - Clones chunks in memory solely for AES-128-CBC / Protobuf decryption & logging.
 */

const net = require('net');
const http = require('http');
const { parseTcpFrame, sessionState } = require('../crypto/cipherEngine');
const { createHttpHandler } = require('./httpInterceptor');

const HTTP_FIRST_WORDS = ['GET ', 'POST', 'PUT ', 'DELE', 'HEAD', 'OPTI', 'PATC', 'CONN'];

function extractTlsSni(buf) {
  try {
    if (!buf || buf.length < 45) return null;
    if (buf[0] !== 0x16 || buf[1] !== 0x03) return null;
    let pos = 5;
    if (buf[pos] !== 0x01) return null;
    pos += 4 + 2 + 32;
    if (pos >= buf.length) return null;
    const sessionIdLen = buf[pos];
    pos += 1 + sessionIdLen;
    if (pos + 2 > buf.length) return null;
    const cipherSuitesLen = buf.readUInt16BE(pos);
    pos += 2 + cipherSuitesLen;
    if (pos + 1 > buf.length) return null;
    const compMethodsLen = buf[pos];
    pos += 1 + compMethodsLen;
    if (pos + 2 > buf.length) return null;
    const extensionsLen = buf.readUInt16BE(pos);
    pos += 2;
    const extEnd = Math.min(buf.length, pos + extensionsLen);
    while (pos + 4 <= extEnd) {
      const extType = buf.readUInt16BE(pos);
      const extLen = buf.readUInt16BE(pos + 2);
      pos += 4;
      if (extType === 0x0000 && pos + 5 <= extEnd) {
        const nameType = buf[pos + 2];
        const nameLen = buf.readUInt16BE(pos + 3);
        if (nameType === 0 && pos + 5 + nameLen <= extEnd) {
          return buf.subarray(pos + 5, pos + 5 + nameLen).toString('utf8');
        }
      }
      pos += extLen;
    }
  } catch (_) {}
  return null;
}

function attachRawTcpFrameInspector({
  clientSocket,
  upstreamSocket,
  clientAddr,
  targetAddr,
  initialChunk,
  onPacket
}) {
  const handleClientChunk = (chunk) => {
    // Forward exact untouched encrypted bytes first for zero latency/tampering
    if (upstreamSocket && !upstreamSocket.destroyed && upstreamSocket.writable) {
      upstreamSocket.write(chunk);
    }
    const parsed = parseTcpFrame(Buffer.from(chunk), 'CLIENT->SERVER');
    const evt = {
      id: `TCP-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      protocol: 'TCP',
      direction: 'CLIENT -> SERVER',
      statusCode: 200,
      passthroughMode: 'EXACT_ENCRYPTED_WIRE_PASSTHROUGH',
      requestTitle: `[TCP OUTGOING REQUEST] ${parsed.packetType || 'TCP_FRAME'} (${clientAddr} -> ${targetAddr})`,
      responseTitle: `[TCP PASSTHROUGH] Status: 200 OK -> ${targetAddr}`,
      timestamp: new Date().toISOString(),
      source: clientAddr,
      destination: targetAddr,
      size: chunk.length,
      ...parsed
    };
    if (onPacket) onPacket(evt, sessionState);
  };

  const handleServerChunk = (chunk) => {
    // Return exact untouched encrypted bytes to client immediately
    if (clientSocket && !clientSocket.destroyed && clientSocket.writable) {
      clientSocket.write(chunk);
    }
    const parsed = parseTcpFrame(Buffer.from(chunk), 'SERVER->CLIENT');
    const evt = {
      id: `TCP-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      protocol: 'TCP',
      direction: 'SERVER -> CLIENT',
      statusCode: 200,
      passthroughMode: 'EXACT_ENCRYPTED_WIRE_PASSTHROUGH',
      requestTitle: `[TCP STREAM] ${targetAddr} -> ${clientAddr}`,
      responseTitle: `[TCP INCOMING RESPONSE] Status: 200 OK | ${parsed.packetType || 'TCP_FRAME'}`,
      timestamp: new Date().toISOString(),
      source: targetAddr,
      destination: clientAddr,
      size: chunk.length,
      ...parsed
    };
    if (onPacket) onPacket(evt, sessionState);
  };

  if (initialChunk && initialChunk.length > 0) {
    handleClientChunk(initialChunk);
  }

  clientSocket.on('data', handleClientChunk);
  if (upstreamSocket) {
    upstreamSocket.on('data', handleServerChunk);
  }
}

function createUnifiedPort8080Server({
  listenPort = 8080,
  defaultTcpTargetHost = '127.0.0.1',
  defaultTcpTargetPort = 39003,
  onPacket
}) {
  const httpHandler = createHttpHandler({ onPacket });
  const internalHttpServer = http.createServer(httpHandler);

  internalHttpServer.on('connect', (req, clientSocket, head) => {
    const startTime = Date.now();
    const [targetHost, targetPortStr] = (req.url || '').split(':');
    const targetPort = Number(targetPortStr) || 443;
    const clientAddr = `${clientSocket.remoteAddress || 'client'}:${clientSocket.remotePort || ''}`;
    const targetAddr = `${targetHost}:${targetPort}`;

    const serverSocket = net.connect(targetPort, targetHost, () => {
      // Pure standard HTTP/1.1 200 Connection Established with NO Proxy-Agent header
      clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');

      let firstChunkInspected = false;
      let isRawGameTcp = false;

      const inspectChunk = (chunk, dir) => {
        if (!firstChunkInspected && dir === 'C->S') {
          firstChunkInspected = true;
          const sni = extractTlsSni(chunk);
          if (chunk[0] === 0x16 && chunk[1] === 0x03) {
            const evt = {
              id: `HTTP-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
              protocol: 'HTTP',
              direction: 'CONNECT TUNNEL',
              timestamp: new Date().toISOString(),
              durationMs: Date.now() - startTime,
              method: 'CONNECT',
              fullUrl: `https://${sni || targetHost}:${targetPort}/`,
              host: sni || targetHost,
              path: '/',
              queryParams: {},
              statusCode: 200,
              passthroughMode: 'EXACT_TLS_PASSTHROUGH',
              requestTitle: `CONNECT https://${sni || targetHost}:${targetPort}/ (TLS SNI: ${sni || targetHost})`,
              responseTitle: `200 Connection Established <- ${targetAddr}`,
              request: {
                headers: req.headers,
                size: chunk.length,
                encryption: `TLS_PASSTHROUGH (SNI=${sni || targetHost})`,
                rawHex: chunk.subarray(0, 64).toString('hex'),
                decryptedHex: '',
                decoded: {
                  tunnel_target: targetAddr,
                  tls_sni_hostname: sni || targetHost,
                  client_hello_bytes: chunk.length
                }
              },
              response: {
                headers: { status: '200 Connection Established' },
                size: 0,
                encryption: 'TLS_TUNNEL_ESTABLISHED',
                rawHex: '',
                decryptedHex: '',
                decoded: { status: '200 Connection Established', upstream: targetAddr }
              }
            };
            if (onPacket) onPacket(evt, sessionState);
          } else {
            isRawGameTcp = true;
          }
        }

        if (isRawGameTcp) {
          const parsed = parseTcpFrame(Buffer.from(chunk), dir === 'C->S' ? 'CLIENT->SERVER' : 'SERVER->CLIENT');
          const evt = {
            id: `TCP-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            protocol: 'TCP',
            direction: dir === 'C->S' ? 'CLIENT -> SERVER' : 'SERVER -> CLIENT',
            statusCode: 200,
            passthroughMode: 'EXACT_ENCRYPTED_WIRE_PASSTHROUGH',
            requestTitle: dir === 'C->S'
              ? `[TCP REQUEST] ${parsed.packetType} (${clientAddr} -> ${targetAddr})`
              : `[TCP STREAM] ${targetAddr} -> ${clientAddr}`,
            responseTitle: dir === 'S->C'
              ? `[TCP RESPONSE] Status: 200 OK | ${parsed.packetType} <- ${targetAddr}`
              : `[TCP FORWARDED] Status: 200 OK -> ${targetAddr}`,
            timestamp: new Date().toISOString(),
            source: dir === 'C->S' ? clientAddr : targetAddr,
            destination: dir === 'C->S' ? targetAddr : clientAddr,
            size: chunk.length,
            ...parsed
          };
          if (onPacket) onPacket(evt, sessionState);
        }
      };

      if (head && head.length > 0) {
        if (!serverSocket.destroyed) serverSocket.write(head);
        inspectChunk(head, 'C->S');
      }

      clientSocket.on('data', (chunk) => {
        if (!serverSocket.destroyed) serverSocket.write(chunk);
        inspectChunk(chunk, 'C->S');
      });

      serverSocket.on('data', (chunk) => {
        if (!clientSocket.destroyed) clientSocket.write(chunk);
        inspectChunk(chunk, 'S->C');
      });
    });

    serverSocket.on('error', () => clientSocket.destroy());
    clientSocket.on('error', () => serverSocket.destroy());
  });

  const muxServer = net.createServer((socket) => {
    socket.once('data', (firstChunk) => {
      const prefixAscii = firstChunk.subarray(0, 4).toString('ascii').toUpperCase();
      const isHttp = HTTP_FIRST_WORDS.includes(prefixAscii);

      if (isHttp) {
        internalHttpServer.emit('connection', socket);
        socket.unshift(firstChunk);
      } else {
        let targetHost = defaultTcpTargetHost;
        let targetPort = defaultTcpTargetPort;
        if (sessionState.functionalAddr && sessionState.functionalAddr.includes(':')) {
          const [h, p] = sessionState.functionalAddr.split(':');
          if (h && Number(p)) {
            targetHost = h;
            targetPort = Number(p);
          }
        }
        const clientAddr = `${socket.remoteAddress || 'client'}:${socket.remotePort || ''}`;
        const targetAddr = `${targetHost}:${targetPort}`;

        const upstreamSocket = new net.Socket();
        if (!(targetHost === '127.0.0.1' && targetPort === listenPort)) {
          upstreamSocket.connect(targetPort, targetHost, () => {});
        }
        upstreamSocket.on('error', () => {});

        attachRawTcpFrameInspector({
          clientSocket: socket,
          upstreamSocket,
          clientAddr,
          targetAddr,
          initialChunk: firstChunk,
          onPacket
        });

        socket.on('close', () => upstreamSocket.destroy());
        socket.on('error', () => upstreamSocket.destroy());
      }
    });

    socket.on('error', () => {});
  });

  return {
    server: muxServer,
    start: () =>
      new Promise((resolve) => {
        muxServer.listen(listenPort, '0.0.0.0', () => resolve(listenPort));
      })
  };
}

module.exports = {
  createUnifiedPort8080Server,
  extractTlsSni
};
